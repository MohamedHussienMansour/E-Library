#include <stdio.h>
#include <string.h>
#include "STD_TYPES.h"
#include "Library.c"
int main() {
    u32 Method;
    u8 quit;
    u32 id;
    u8 nameB[20];
    u8 nameA[20];
    f32 P;
    u8 Emails[20][20];
    u8 Passwords[20][20];
    u8 Email[20];
    u8 Password[20];
    u8 cheak='n';

    u8 flag=0;
    u8 flag2=0;
    u8 count_account=0;
    login:
    while(cheak !='y' || flag !=1){
    printf("Do you have an account? if yes Enter 'y' and if you want to create one Enter anything else : ");
    scanf(" %c",&cheak);
    if (cheak=='y'){
    printf("Please Enter Email and Password for your account \nEmail: ");
    scanf(" %[^\n]s",&Email);
    printf("Password: ");
    scanf(" %[^\n]s",&Password);

    }
    else{
    flag2=0;
    while (0==flag2){
    printf("Please Enter Email and Password for your account you want to create \nEmail: ");

    scanf(" %[^\n]s",&Emails[count_account]);
    flag2=1;

    for(u8 i=0;i<20;i++){
        if (strcmp(Emails[i],Emails[count_account])==0 && i!=count_account){
                printf("This Email is in our system you cannot use it\n");
                flag2=0;
                break;

        }
        else{

        }}




    }
    printf("Password: ");
    scanf(" %[^\n]s",&Passwords[count_account]);
    count_account++;
    continue;
    }


    for(u8 i=0;i<20;i++){
        if (strcmp(Emails[i],Email)==0 && strcmp(Passwords[i],Password)==0){
                flag= 1;
                break;

        }
        else{

        }}
    if (flag==0){
        printf("in valid Email or Password\n");
    }
    else{
    }



    }

    // ... Account management code ...
    Label:
    printf("Hello to our Library\nChoose The Method you want do in Library\n'A' --> Add Book\n'D' --> Delete Book\n'V' --> View Book\nEnter The Letter refer to Method: ");
    scanf(" %c",&Method);

    while (1) {
        // ... Display main menu ...

        switch (Method) {
            case 'A':
            case 'a':
                // ... Prompt user for book details ...
        printf("Enter Id of The Book:");
        scanf(" %i",&id);
        printf("Enter Name of the Book of The Book:");
        scanf(" %[^\n]s",&nameB);
        printf("Enter Name of the Author of The Book:");
        scanf(" %[^\n]s",&nameA);
        printf("Enter Price of The Book:");
        scanf(" %f",&P);
                Add_Book(id, nameB, nameA, P);
                break;
            case 'D':
            case 'd':
                // ... Prompt user for book ID ...
                            printf("Enter Id of The Book you want to delete:");
            scanf(" %i", &id);
                Delete_Book(id);
                break;
            case 'V':
            case 'v':
                View_Book();
                break;
            default:
                printf("... Invalid input handling ...");
                break;
        }

        // ... Ask user if they want to continue ...
    printf("if you want to quit press 'q' if you to return to login press 'l' else Enter another thing :");
    scanf(" %c",&quit);
    if (quit=='q'){
        return 0;
    }
    else if(quit=='l'){
        goto login;
    }

    else{
        goto Label;
    }
    }

    // ... Clean up memory before exiting ...

    return 0;
}
