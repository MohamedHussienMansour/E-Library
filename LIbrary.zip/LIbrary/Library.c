#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Library.h"

struct Node {
    u32 id;
    u8 nameBook[20];
    u8 nameAuthor[20];
    f32 price;
    struct Node* next;
    struct Node* prev;
};

static Node* head = NULL;
void Add_Book(u32 id, u8 nameB[], u8 nameA[], f32 P) {
    Node* current = head;
    while (current != NULL) {
        if (current->id == id) {
            printf("Book with ID %d already exists in the library. Please enter a different ID.\n", id);
            printf("Enter another Id of The Book:");
        scanf(" %i",&id);

        Add_Book(id,nameB,nameA,P);
        return;

        }
        current = current->next;
    }
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (newNode == NULL) {
        printf("Memory allocation failed\n");
        return;
    }

    newNode->id = id;
    strcpy(newNode->nameBook, nameB);
    strcpy(newNode->nameAuthor, nameA);
    newNode->price = P;
    newNode->next = NULL;
    newNode->prev = NULL;

    if (head == NULL) {
        head = newNode;
    } else {
        Node* current = head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = newNode;
        newNode->prev = current;
    }
}

void Delete_Book(u32 id) {
    Node* current = head;
    while (current != NULL) {
        if (current->id == id) {
            if (current->prev != NULL) {
                current->prev->next = current->next;
            } else {
                head = current->next;
            }

            if (current->next != NULL) {
                current->next->prev = current->prev;
            }

            free(current);
            return;
        }
        current = current->next;
    }
    printf("Book with ID %d not found\n", id);
}

void View_Book() {
    Node* current = head;
    while (current != NULL) {
        printf("Book Id: %d\n", current->id);
        printf("Book Name: %s\n", current->nameBook);
        printf("Author Name: %s\n", current->nameAuthor);
        printf("Price: %.2f\n\n", current->price);
        current = current->next;
    }}
