#ifndef LIBRARY_H
#define LIBRARY_H

#include "STD_TYPES.h"

typedef struct Node Node;

void Add_Book(u32 id, u8 nameB[], u8 nameA[], f32 P);
void Delete_Book(u32 id);
void View_Book();

#endif // LIBRARY_H


